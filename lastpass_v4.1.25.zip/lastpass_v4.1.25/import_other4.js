document.getElementById("import").value=gs("Import");document.getElementById("choosefile").style.display=g_getfile?"block":"none";
