document.addEventListener("DOMContentLoaded",function(){chrome.runtime.getBackgroundPage(function(a){window.bg=a;VaultState.startInitializeInterval()})});
