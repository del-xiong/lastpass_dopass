sr(document,"chooseprofileccok","value","OK");sr(document,"chooseprofilecccancel","value","Cancel");
