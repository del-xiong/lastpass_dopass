var LPSTAT={};
