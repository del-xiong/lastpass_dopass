dialogs.reprompt=dialogs.reprompt.extend({htmlSource:"vaultRepromptDialog.html",css:"vaultRepromptDialog",js:"vaultRepromptDialog",type:"VaultRepromptDialog"});
