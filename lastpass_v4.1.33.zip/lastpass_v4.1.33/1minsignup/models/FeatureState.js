var oneMinuteSignup = oneMinuteSignup || {};
oneMinuteSignup.FeatureState = {
    started: 'started',
    postpone: 'postpone',
    cancel: 'cancel'
};
