var oneMinuteSignup = oneMinuteSignup || {};
oneMinuteSignup.MessageType = {
    ResetRequestScript: "ResetRequestScript",
    ResetScript: "ResetScript",
    LogoutScript: "LogoutScript",
    UserInformationNeeded: "UserInformationNeeded",
    NavigateToTab: "NavigateToTab",
    SaveDiscoveredApps: "SaveDiscoveredApps",
    Done: "Done",
    Error: "Error",
    Log: "Log",
    SavedToVault: "SavedToVault",
    GetToken: "GetToken",
    LaunchApplication: "LaunchApplication",
    CloseTab: "CloseTab",
    GetOauthToken: "getOauthToken",
    ReceivedOauthToken: "token"
};