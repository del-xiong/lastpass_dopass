var oneMinuteSignup = oneMinuteSignup || {};
oneMinuteSignup.ScriptState = {
    done: 'done',
    running: 'running',
    suspended: 'suspended'
};
