var oneMinuteSignup = oneMinuteSignup || {};
oneMinuteSignup.ScriptType = {
    request: 'request',
    change: 'change',
    logout: 'logout'
};
