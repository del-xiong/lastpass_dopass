var oneMinuteSignup = oneMinuteSignup || {};
oneMinuteSignup.Tab = function (id, url) {
    this.id = id;
    this.url = url;
};
