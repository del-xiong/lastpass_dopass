BuildVariables={partner:"",getPartnerURL:function(a){this.partner&&(a+=(0<=a.indexOf("?")?"&":"?")+"partnername="+encodeURIComponent(this.partner));return a},createSource:"google"};
