Interfaces.ContentScriptDialogInterface=function(){return{LPDialog:{openDialog:new Interfaces.Definition(Interfaces.TYPE_FUNCTION)}}}();
