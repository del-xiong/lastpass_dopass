Interfaces.ExtensionLoginDropdownInterface=function(){var a=Interfaces.Definition,b=Interfaces.TYPE_FUNCTION;return{ExtensionDropdown:{open:new a(b),reset:new a(b)}}}();
