Interfaces.InfieldPopupInterface=function(){return{lpInfield:{setArrowPosition:new Interfaces.Definition(Interfaces.TYPE_FUNCTION,{include:["contentScript"]})}}}();
