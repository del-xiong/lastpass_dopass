sr(document,"generatebutton","value","Generate");sr(document,"generatesave","value",!getBG().can_copy_to_clipboard()?"Save":"Copy");sr(document,"generateclose","value","Close");
