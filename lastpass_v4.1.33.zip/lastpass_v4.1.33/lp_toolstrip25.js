set_innertext(document.getElementById("changepwchange"),gs("Change"));set_innertext(document.getElementById("changepwclose"),gs("Close"));
