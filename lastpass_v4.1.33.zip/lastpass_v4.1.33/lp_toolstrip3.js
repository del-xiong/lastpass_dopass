sr(document,"notifysavesitebtn","value","Save Site");sr(document,"notifyneverbtn","value","Never...");sr(document,"notifyclosebtn","value","Close");
