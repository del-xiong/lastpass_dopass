document.getElementById("sesameauth")&&set_innertext(document.getElementById("sesameauth"),gs("Authenticate"));
