sr(document,"ok","value","OK");sr(document,"cancel","value","Cancel");
