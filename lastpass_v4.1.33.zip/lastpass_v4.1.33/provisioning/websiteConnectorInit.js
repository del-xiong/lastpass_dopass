document.addEventListener( "DOMContentLoaded", function(){
            document.removeEventListener( "DOMContentLoaded", arguments.callee, false );
			document.body.setAttribute('lastpass-extension-id', '1');
			document.body.setAttribute('lastpass-extension-version', '1');
        }, false );
