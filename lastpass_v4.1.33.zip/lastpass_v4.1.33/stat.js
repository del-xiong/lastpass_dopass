var LPSTAT={};
