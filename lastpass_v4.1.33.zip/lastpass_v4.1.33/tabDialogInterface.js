Interfaces.TabDialogInterface=function(){return{LPTabDialog:{openDialog:new Interfaces.Definition(Interfaces.TYPE_FUNCTION)}}}();
